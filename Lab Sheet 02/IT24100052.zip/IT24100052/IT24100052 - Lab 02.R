# 1
nums <- 1: 15 # Define the vector
nums_divisable <- nums[nums %% 3 == 0] # Get the divisable from nums
element_count = length(nums_divisable) # Get the count : length of the vector
print(element_count)

# 2
nums <- c(10, 22, 312, 21, 43, 543) # Define the vector
maximum_index <- 1
vector_length = length(nums)
for (i in 1: vector_length){
  if (maximum_index < nums[i]){
    maximum_index <- i
  }
}
print(maximum_index)

# 3
nums <- c(10, 22, 312, 21, 43, 543)
max_index <- which.max(nums) # get the maximux value index
print(max_index)