# 1
a <- 10
b <- 3

# 2
a + b
a %/% b
a %% b
a ^ b

# 3
a > b
b == 3
a > 5 | b < 2

# 4
scores <- c(85, 90, 78, 92, NA, 88)
class(scores)
mean(scores, na.rm = TRUE)
scores[!is.na(scores) & scores > 85]

# 5
names <- c("Alice", "Bob", "Charlie", "Diana", "Evan", "Fiona")
passed <- scores >= 80

# 6
results <- data.frame(Name=names, Score=scores, Passed = passed)

# 7
str(results)
print(results)

# 8
max(results$Score, na.rm = TRUE)